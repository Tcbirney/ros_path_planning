Instructions:

To run this program, simply run the .py file, making sure all libraries are installed.
You will be prompted for the start and goal locations of the robot. Just make
sure the start and end points are within the bounds and unoccupied by an obstacle or margin

This script will produce a video of the search pattern provided your initialization configuration.

The video provided has the configuration of

start_x = 0.25
start_y = 0.25
start_theta = 0 

goal_x = 9
goal_y = 6
goal_theta = 0 

Any other inquires can be sent to tbirney@umd.edu
Operation can be seen in the included test.avi file
Code can be found at: https://github.com/njnovak/ENPM-661-Project-3
See each file's comments for further explanations
